package com.example.project8k.model

data class Member(val name: String, val surname: String)